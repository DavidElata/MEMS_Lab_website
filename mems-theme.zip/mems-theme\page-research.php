<?php get_header(); ?>

    <main>

        <!-- Entry 1 -->
        <div class="research-entry">
            <h2>The intermediate frequency effect and Dzhanibekov-like transitions in the response of the anisotropic pendulum</h2>
            <div class="research-media">
                <video autoplay loop muted playsinline>
                    <source src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Theta_large_2.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
            <p class="abstract">The anisotropic pendulum has three distinct primary periodic motions of free vibration, but only if the level of energy is above a critical threshold. It is shown that the primary periodic motion with the intermediate frequency is inherently unstable and exhibits Dzhanibekov-like transitions. This work explains the sensitivity of the Foucault pendulum to even a slight anisotropy of its suspension – a problem that Léon Foucault identified in 1851.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                Eli Benvenisty and David Elata, "The intermediate frequency effect and Dzhanibekov-like transitions in the response of the anisotropic pendulum",
                <em>Nonlinear Dynamics</em>, Volume 114, Article number 466, 2026.
                DOI: <a href="https://doi.org/10.1007/s11071-026-12324-y" target="_blank" rel="noopener">10.1007/s11071-026-12324-y</a>
            </div>
        </div>

        <!-- Entry 2 -->
        <div class="research-entry">
            <h2>Periodic Dzhanibekov-like transitions of the double pendulum</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/2026_JSV_Double_Pendulum.png" alt="Periodic Dzhanibekov-like transitions of the double pendulum">
            </div>
            <p class="abstract">The double pendulum is a well-known nonlinear dynamic system. Many previous studies considered one or more of its three categories of response: periodic (a.k.a. normal), regular (a.k.a. quasi-periodic), and chaotic. In this study, we show a new fourth category of response that we term Dzhanibekov-like transitions. It begins with a nearly periodic response, then in a fast transition, it diverges and converges to a second nearly periodic response. These sequential transitions between the two nearly periodic responses are repeated at regular time intervals. We demonstrate symmetric and asymmetric Dzhanibekov-like transitions.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                E. Benvenisty, O. Shoshani and D. Elata, "Periodic Dzhanibekov-like transitions of the double pendulum",
                <em>Journal of Sound and Vibration</em>, Volume 634, Art no. 119785, 2026.
                DOI: <a href="https://doi.org/10.1016/j.jsv.2026.119785" target="_blank" rel="noopener">10.1016/j.jsv.2026.119785</a>
            </div>
        </div>

        <!-- Entry 3 -->
        <div class="research-entry">
            <h2>The elastic pendulum - Dzhanibekov-like transitions of symmetric and asymmetric periodic responses</h2>
            <div class="research-media">
                <video autoplay loop muted playsinline>
                    <source src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/elastic_pendulum_symmetric_Dzhanibekov.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
            <p class="abstract">It has been shown in many previous studies that the free-vibration response of the elastic pendulum can be chaotic, quasi-periodic, or periodic. We present a new category of response: a slow sequential, back-and-forth switching between a nearly periodic response and its mirror-image. This switching resembles the Dzhanibekov effect. We show that the frequency of switching is unrelated to the frequency of the pendulum swings but rather depends on initial conditions.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                E. Benvenisty, O. Shoshani and D. Elata, "The elastic pendulum - Dzhanibekov-like transitions of symmetric and asymmetric periodic responses",
                <em>Nonlinear Dynamics</em>, Volume 113, pages 20841–20853, 2025.
                DOI: <a href="https://doi.org/10.1007/s11071-025-11242-9" target="_blank" rel="noopener">10.1007/s11071-025-11242-9</a>
            </div>
        </div>

        <!-- Entry 4 -->
        <div class="research-entry">
            <h2>Flexural vibrations of anisotropic thin rotating rings</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Rotating_anisotropic_rings.gif" alt="Flexural vibrations of anisotropic thin rotating rings">
            </div>
            <p class="abstract">We present a rigorous analysis of the in-plane flexural vibrations of a thin rotating circular ring. The ring is made from an anisotropic material with cubic symmetry, as in (100) single-crystalline silicon. In this study, both the natural frequencies and their related mode shapes are analytically derived using an asymptotic method, for the modes numbered n=2, 3 and 4. We show that due to a rate of rotation, these modes exhibit a precession-like response, which was previously shown to occur in isotropic rings. However, for rotating rings that are made from an anisotropic material, we show that the even-ordered modes n=2 and n=4, exhibit a 'breathing' phenomenon in the precessing mode.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                D. Rosenstock and D. Elata, "On the flexural in-plane vibrations of a thin circular ring made from an elastic solid with cubic crystalline symmetry".
                <em>Journal of Sound and Vibration</em>, 562, 2023, 117842.
                DOI: <a href="https://doi.org/10.1016/j.jsv.2023.117842" target="_blank" rel="noopener">10.1016/j.jsv.2023.117842</a><br><br>
                D. Rosenstock and D. Elata, "Flexural vibrations of anisotropic thin rotating rings".
                <em>Journal of Sound and Vibration</em>, 604, Art no. 118924, 2025.
                DOI: <a href="https://doi.org/10.1016/j.jsv.2024.118924" target="_blank" rel="noopener">10.1016/j.jsv.2024.118924</a>
            </div>
        </div>

        <!-- Entry 5 -->
        <div class="research-entry">
            <h2>On the optimal planform of a cantilever unimorph piezoelectric vibrating energy harvester</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Trapeze.png" alt="Optimal planform of a cantilever unimorph piezoelectric vibrating energy harvester">
            </div>
            <p class="abstract">This work considers piezoelectric vibrating energy harvesters, that are constructed from an unimorph cantilever with a massive edge block. The optimal response of such a harvester is achieved when the amplitude of the axial strain in the piezoelectric layer is uniform. The variation of the width along the cantilever is a design choice and we show, for the first time ever, an analytic proof that the optimal planform is a trapeze, where the cantilever tapers from its clamped edge towards the edge block. The predictive capabilities of our model are validated by comparison to finite element simulations.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                E. Salman, S. Lustig and D. Elata, "On the optimal planform of a cantilever unimorph piezoelectric vibrating energy harvester".
                <em>Smart Mater. Struct.</em>, 33, 035029 (7pp), 2024.
                DOI: <a href="https://doi.org/10.1088/1361-665X/ad28d0" target="_blank" rel="noopener">10.1088/1361-665X/ad28d0</a><br><br>
                E. Salman, D. Rosenstock and D. Elata, "The Optimal Axial Strain Distribution in a Piezoelectric Vibrating Energy Harvester (PVEH)".
                <em>Journal of Sensors and Sensor Systems</em>, 14, 147–152, June 2025.
                DOI: <a href="https://doi.org/10.5194/jsss-14-147-2025" target="_blank" rel="noopener">10.5194/jsss-14-147-2025</a><br><br>
                E. Salman, S. Lustig and D. Elata, "The optimal planform of a cantilever unimorph piezoelectric vibrating energy harvester (PVEH) that has a device-layer edge block".
                <em>Journal of Sensors and Sensor Systems</em>, 14, 153–159, June 2025.
                DOI: <a href="https://doi.org/10.5194/jsss-14-153-2025" target="_blank" rel="noopener">10.5194/jsss-14-153-2025</a>
            </div>
        </div>

        <!-- Entry 6 -->
        <div class="research-entry">
            <h2>Harmonic biasing in a double-sided comb-drive resonator, for resolving feed-through issues in low-power driving</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Harmonic biasing.PNG" alt="Harmonic biasing in a double-sided comb-drive resonator">
            </div>
            <p class="abstract">We demonstrate a novel technique for operating a differentially-driven and differentially-sensed double-sided comb-drive resonator. The resonator is driven by application of two out-of-phase ac signals to the drive stators, while the rotor is subjected to a pure harmonic signal at the same frequency as of the ac driving signals. In this mode of operation, no dc bias is necessary. This strategy results in two frequency-mixing operations, such that a clear response can be sensed at the 3rd harmonic of the drive signal. With harmonic biasing, the resonator is insensitive to both feed-through currents that result from direct capacitive cross-coupling of sense and drive pads, and to feed-through currents that result from imbalanced sense ports due to packaging and setup.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                D. A. Kassie and D. Elata, "Harmonic biasing in a double-sided comb-drive resonator, for resolving feed-through issues in low-power driving",
                <em>Sensors and Actuators A Physical</em>, 332(1), 113031, 2021.
                DOI: <a href="https://doi.org/10.1016/j.sna.2021.113031" target="_blank" rel="noopener">10.1016/j.sna.2021.113031</a>
            </div>
        </div>

        <!-- Entry 7 -->
        <div class="research-entry">
            <h2>What is the resonance of a linear mechanical resonator, peak amplitude of displacement or peak amplitude of velocity?</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Resonanca.PNG" alt="Resonance of a Linear Mechanical Resonator">
            </div>
            <p class="abstract">There is some ambiguity in literature with respect to the resonance response of mechanical resonators. Should resonance be associated with the peak amplitude of velocity or should it be associated with the peak amplitude of displacement? Another ambiguity relates to the definition of phase: should phase relate velocity or displacement to the driving force? These two issues are addressed here, and it is shown why resonance should be associated with peak amplitude of velocity, and not with peak amplitude of displacement.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                D. Elata, "What is the resonance of a linear mechanical resonator, peak amplitude of displacement or peak amplitude of velocity?",
                <em>IEEE Sensors Letters</em>, 7(11), 1-3, Nov. 2023, Art no. 1501603.
                DOI: <a href="https://doi.org/10.1109/LSENS.2023.3320566" target="_blank" rel="noopener">10.1109/LSENS.2023.3320566</a>
            </div>
        </div>

        <!-- Entry 8 -->
        <div class="research-entry">
            <h2>Parametric resonance in a double-sided comb-drive actuator with a floating rotor</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Float.png" alt="Parametric resonance in a double-sided comb-drive actuator with a floating rotor">
            </div>
            <p class="abstract">The common double-sided comb-drive electrostatic resonator responds as a parametric resonator when its rotor is electrostatically floating. Small ac signals that drive the system are sufficient to produce a large amplitude of harmonic response, without requiring any dc bias. We demonstrate that the system can be driven to resonance, by driving it at unit-fractions of the fundamental frequency.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                D. A. Kassie, S. Levi and D. Elata, "A double-sided comb-drive actuator with a floating rotor: Achieving a strong response while eliminating the dc bias",
                <em>IEEE-JMEMS</em>, 29(5), 1173–1179, 2020.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2020.3004831" target="_blank" rel="noopener">10.1109/JMEMS.2020.3004831</a><br><br>
                D. A. Kassie and D. Elata, "Parametric resonators with a floating rotor: sensing strategy for devices with an increased stiffness and compact design",
                <em>IEEE-JMEMS</em>, 30(3), 411–418, 2021.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2021.3065424" target="_blank" rel="noopener">10.1109/JMEMS.2021.3065424</a>
            </div>
        </div>

        <!-- Entry 9 -->
        <div class="research-entry">
            <h2>Rigorous and insightful discussion of the piezoelectric coupling factor</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Coupling factor.png" alt="Piezoelectric coupling factor">
            </div>
            <p class="abstract">The piezoelectric coupling factor is defined as the ratio between the converted energy and the supplied energy. This factor is often considered as a measure of the transduction efficiency of the material. Another definition of the coupling factor is a non-dimensional ratio of material coefficients. We show that in some specific cases, the two definitions are equivalent, but that in other cases they are incompatible. In addition, we show that in specific quasi-static loading cycles, the converted energy may be increased by a slight modification of the unloading part of the cycle.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                S. Lustig and D. Elata, "Ambiguous definitions of the piezoelectric coupling factor",
                <em>Journal of Intelligent Material Systems and Structures</em>, 31(14), 1689–1696, 2020.
                DOI: <a href="https://doi.org/10.1177/1045389X20930104" target="_blank" rel="noopener">10.1177/1045389X20930104</a>
            </div>
        </div>

        <!-- Entry 10 -->
        <div class="research-entry">
            <h2>Frequency matching of orthogonal wineglass modes in disk and ring resonators made from (100) silicon</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Frequency matching.png" alt="Frequency matching of orthogonal wineglass modes">
            </div>
            <p class="abstract">Vibrational wineglass modes in disk and rings that are made from (100) silicon are considered. It is shown that all odd-ordered wineglass modes are necessarily frequency-matched, each with its orthogonal conjugate. In contrast, all even-ordered wineglass modes are likely not to be frequency-matched with their orthogonal conjugate. Some specific cases are presented that show that many wineglass modes do not have a rotational periodic symmetry. This is relevant to disks and rings that are driven and sensed by surrounding gap-closing electrostatic actuators.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                E. Benvenisty and D. Elata, "Frequency matching of orthogonal wineglass modes in disk and ring resonators made from (100) silicon",
                <em>IEEE Sensors Letters</em>, 3(3), 1-4, 2019.
                DOI: <a href="https://doi.org/10.1109/LSENS.2019.2901129" target="_blank" rel="noopener">10.1109/LSENS.2019.2901129</a>
            </div>
        </div>

        <!-- Entry 11 -->
        <div class="research-entry">
            <h2>MEMS parametric resonators</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/MEMS parametric resonator.png" alt="MEMS parametric resonators">
            </div>
            <p class="abstract">We present a MEMS realization of a classic parametric resonator. This parametric resonator is ideal in the sense that the electrostatic stiffness, which may be time-modulated, is not affected by motion. We also present a simple, efficient and intuitive model of parametric excitation. This model predicts the minimal modulation amplitude required to obtain an unbounded response in a parametric system with linear damping. We show experimental results in which the system is operated as a Meissner resonator.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                S. Shmulevich, I. Hotzen and D. Elata, "A MEMS implementation of a classic parametric resonator",
                <em>IEEE-JMEMS</em>, 24(5), 1285–1292, 2015.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2015.2402223" target="_blank" rel="noopener">10.1109/JMEMS.2015.2402223</a><br><br>
                S. Shmulevich and D. Elata, "A MEMS implementation of the classic Meissner parametric resonator: exploring high-order windows of unbounded response",
                <em>IEEE-JMEMS</em>, 26(2), 325–332, 2017.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2016.2645878" target="_blank" rel="noopener">10.1109/JMEMS.2016.2645878</a>
            </div>
        </div>

        <!-- Entry 12 -->
        <div class="research-entry">
            <h2>A piezoelectric twisting beam actuator</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Twisting beam.png" alt="A piezoelectric twisting beam actuator">
            </div>
            <p class="abstract">We demonstrated, for the first time ever, a piezoelectric beam actuator that responds in pure twist. The actuator is constructed from bulk PZT, and interdigitated electrodes that are rotated at 45º relative to the beam axis, are used for both poling and driving.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                I. (Hotzen) Grinberg, N. Maccabi, A. Kassie, D. Elata, "A piezoelectric twisting beam actuator",
                <em>IEEE-JMEMS</em>, 26(6), 1279-1286, 2017.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2017.2731120" target="_blank" rel="noopener">10.1109/JMEMS.2017.2731120</a><br><br>
                I. (Hotzen) Grinberg, N. Maccabi, A. Kassie, D. Elata, "A pure-twisting piezoelectric actuator for tilting micromirror applications",
                <em>IEEE-Transducers2017</em>, Kaohsiung, Taiwan, June 18-22, 2017.
                DOI: <a href="https://doi.org/10.1109/TRANSDUCERS.2017.7994472" target="_blank" rel="noopener">10.1109/TRANSDUCERS.2017.7994472</a><br><br>
                I. (Hotzen) Grinberg, N. Maccabi, A. Kassie, D. Elata, "A bulk-unimorph PZT actuator for large piston motions with 2-axis small angle adjustments",
                <em>IEEE-Transducers2017</em>, Kaohsiung, Taiwan, June 18-22, 2017.
                DOI: <a href="https://doi.org/10.1109/TRANSDUCERS.2017.7994468" target="_blank" rel="noopener">10.1109/TRANSDUCERS.2017.7994468</a>
            </div>
        </div>

        <!-- Entry 13 -->
        <div class="research-entry">
            <h2>Selective stiffening for enhancing and/or reversing the action of thermoelastic actuators</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Thermal motion conversion.png" alt="Selective stiffening for thermoelastic actuators">
            </div>
            <p class="abstract">We present a thermoelastic micromotor for driving a rigid plate in an out-of-plane motion. Heating generates isotropic internal bending moments in the bimorphs. We show that this bending produces only small deflections of the plate. To improve the performance of the actuator, we use selective stiffeners to convert bending into torsional deformation of the spiral arms. In one orientation of the stiffeners, this conversion may be used to achieve a seven-fold increase of the thermoelastic response of the actuator. In a different orientation of the stiffeners, a complete reversal of the enhanced thermoelastic response is achieved.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                I. (Hotzen) Grinberg, S. Shmulevich and D. Elata, "Selective stiffening for enhancing and/or reversing the action of thermoelastic actuators",
                <em>IEEE-JMEMS</em>, 25(6), 999-1004, 2016.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2016.2603539" target="_blank" rel="noopener">10.1109/JMEMS.2016.2603539</a>
            </div>
        </div>

        <!-- Entry 14 -->
        <div class="research-entry">
            <h2>Motion conversion mechanisms</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Motion conversion mechanisms.png" alt="Motion conversion mechanisms">
            </div>
            <p class="abstract">We present a mechanism that converts in-plane to out-of-plane motions, which is fully compatible with mass-fabrication processes. By using selective stiffening we induce coupling between in-plane and out-of-plane responses of the mechanism. The conversion ratio is constant (i.e. linear) and it can be easily tailored by the number of stiffeners used in an otherwise unchanged design planform. The linearity of the motion conversion and the possibility to tailor it, are demonstrated experimentally using dedicated test devices.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                I. (Hotzen) Grinberg, O. Ternyak, S. Shmulevich and D. Elata, "Selective stiffening for producing a mass-fabrication compatible motion conversion mechanism",
                <em>IEEE-JMEMS</em>, 24(6), 2101-2108, 2015.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2015.2474151" target="_blank" rel="noopener">10.1109/JMEMS.2015.2474151</a><br><br>
                I. (Hotzen) Grinberg, S. Shmulevich and D. Elata, "Two-axes actuators (x-z or x-θ) driven by in-line electrostatic comb-drives",
                <em>IEEE-MEMS 2016</em>, Shanghai, China, January 2016.
                DOI: <a href="https://doi.org/10.1109/MEMSYS.2016.7421841" target="_blank" rel="noopener">10.1109/MEMSYS.2016.7421841</a>
            </div>
        </div>

        <!-- Entry 15 -->
        <div class="research-entry">
            <h2>Mechanical rechargeable battery</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Mechanical battery.png" alt="Mechanical rechargeable battery">
            </div>
            <p class="abstract">We present an electrostatic transducer in which voltage remains constant while charge is stored or extracted from the device. We achieve this by designing a nonlinear mechanical spring which exactly counteracts the non-linearity associated with electrostatic attraction forces. In essence the new device responds like a rechargeable battery, only here we store electric energy in elastic deformation, whereas in common batteries electric energy is stored as chemical potential.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                S. Shmulevich, A. Joffe, I. (Hotzen) Grinberg and D. Elata, "On the notion of a mechanical battery",
                <em>IEEE-JMEMS</em>, 24(4), 1085–1091, 2015.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2014.2382638" target="_blank" rel="noopener">10.1109/JMEMS.2014.2382638</a>
            </div>
        </div>

        <!-- Entry 16 -->
        <div class="research-entry">
            <h2>Electromagnetic interaction force between two noncoaxial circular coils</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Two rings.png" alt="Electromagnetic interaction force between two noncoaxial circular coils">
            </div>
            <p class="abstract">The electromagnetic interaction forces between two noncoaxial circular coils have been previously analyzed. In the present study we revisit that solution and rederive these forces in a new functional form which provides new insight. Specifically, we revisit the notion of a neutral plane, at a critical vertical separation, in which alignment forces identically vanish. To this end we present a new simplified 2D model of the problem, in which it is easier to understand the nature of these forces. We show that our simplified 2D model captures the same response characteristics as in the more complex 3D problem of the interaction between coils.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                A. Benhaim, O. Shapira and D. Elata, "Electromagnetic interaction force between two noncoaxial circular coils",
                <em>Mechatronics</em>, 30, 244–253, 2015.
                DOI: <a href="https://doi.org/10.1016/j.mechatronics.2015.07.009" target="_blank" rel="noopener">10.1016/j.mechatronics.2015.07.009</a>
            </div>
        </div>

        <!-- Entry 17 -->
        <div class="research-entry">
            <h2>Dynamically-balanced folded-beam suspensions</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Dynamically balanced FBS.png" alt="Dynamically-balanced folded-beam suspensions">
            </div>
            <p class="abstract">The standard folded-beam suspension is often used in electrostatic comb-drive resonators, with the intention of achieving a system with a linear response. However, we show that the harmonic response of the standard folded-beam suspension is not linear at the fundamental resonance frequency of the system. We show that even though the suspension is intended to respond as a linear spring, it is actually designed to do so only in static loading. We present a solution to the problem in the form of a new dynamically-balanced folded-beam suspension.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                S. Shmulevich and D. Elata, "Dynamically-balanced folded-beam suspensions for resonators",
                <em>IEEE-JMEMS</em>, 24(6), 1965–1972, 2015.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2015.2454593" target="_blank" rel="noopener">10.1109/JMEMS.2015.2454593</a>
            </div>
        </div>

        <!-- Entry 18 -->
        <div class="research-entry">
            <h2>A gap-closing electrostatic actuator with a linear extended range</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Linear extension.png" alt="A gap-closing electrostatic actuator with a linear extended range">
            </div>
            <p class="abstract">We present a gap-closing electrostatic actuator with a linear extended range. We achieve this by designing a nonlinear spring which exactly counteracts the nonlinear effects of electrostatic attraction forces in gap-closing actuators. We demonstrate this on parallel-plates actuators with a nominal gap of g=21µm. The initial response up to a deflection of g/4 is stable and is inevitably nonlinear, but beyond this point we demonstrate good linearity up to a displacement of 85% of the nominal gap. By introducing the nonlinear spring, we also avoid the pull-in instability, which would have occurred at a voltage of 31V. Instead, the system is stable, and the driving voltage may be increased up to 130V where the maximal displacement is achieved.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                S. Shmulevich, B. Rivlin, I. Hotzen and D. Elata, "A gap-closing electrostatic actuator with a linear extended range",
                <em>IEEE-JMEMS</em>, 22(5), 1109–1114, 2013.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2013.2276027" target="_blank" rel="noopener">10.1109/JMEMS.2013.2276027</a>
            </div>
        </div>

        <!-- Entry 19 -->
        <div class="research-entry">
            <h2>An electret gap-closing transducer with a linear response</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/SEPPA.png" alt="An electret gap-closing transducer with a linear response">
            </div>
            <p class="abstract">The electromechanical response of a symmetric electret parallel-plates actuator is analyzed. The actuator is constructed from a dielectric plate that is suspended by a linear spring between two electrodes of a planar capacitor. The dielectric plate is loaded with fixed charge and is displaced due to the interaction between this charge and the electrostatic field. The analysis shows that the displacement of the electret actuator is a linear function of the driving voltage, and that a full range of stable motion can be achieved.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                D. Elata, "The Electromechanical response of a symmetric electret parallel-plates actuator",
                <em>Sensors and Actuators A</em>, 173(1), 197–201, 2012.
                DOI: <a href="https://doi.org/10.1016/j.sna.2011.11.001" target="_blank" rel="noopener">10.1016/j.sna.2011.11.001</a>
            </div>
        </div>

        <!-- Entry 20 -->
        <div class="research-entry">
            <h2>Electromechanical sensing of charge retention on floating electrodes</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Charge pull in.png" alt="Electromechanical sensing of charge retention on floating electrodes">
            </div>
            <p class="abstract">This paper considers the electromechanical response of gap-closing electrostatic actuators that are driven by both voltage and charge. It is shown that the system has two distinct pull-in voltages. It is also shown that the amplitude of charge on the floating electrode is proportional to the average of these two pull-in voltages. Test actuators were designed, fabricated, and characterized, and their measured response validates the theoretical predictions. A nondisruptive measurement of charge is proposed and demonstrated which enables monitoring charge decay over time.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                D. Elata, V. Leus, J. Provine, A. Hirshberg and R. T. Howe, "Electromechanical sensing of charge retention on floating electrodes",
                <em>IEEE-JMEMS</em>, 20(1), 150–156, 2011.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2010.2090499" target="_blank" rel="noopener">10.1109/JMEMS.2010.2090499</a>
            </div>
        </div>

        <!-- Entry 21 -->
        <div class="research-entry">
            <h2>Differential internal dielectric transduction of a Lamé-mode resonator</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Lame dielectric.png" alt="Differential internal dielectric transduction of a Lamé-mode resonator">
            </div>
            <p class="abstract">We implemented a parallel internal electrostatic transduction of a laterally driven Lamé-mode polysilicon resonator. This resonator is fabricated using a commercially available double nanogap process, and it is constructed from intertwined polysilicon comb-drives separated by a 50nm silicon nitride layer which mechanically couples the comb-drives. The transduction electrodes are optimally placed and oriented to maximize electromechanical transduction efficiency for the fundamental Lamé mode. A 128.15 MHz Lamé-mode resonator is driven and sensed differentially resulting in a motional resistance of 30 kΩ and quality factor of Q &gt; 12000 in air.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                M. Ziaei-Moayyed, D. Elata, E. Quévy and R. T. Howe, "Differential internal dielectric transduction of a Lamé-mode resonator",
                <em>J. Micromech. Microeng.</em>, 20(11), 115036 (15 pages), 2010.
                DOI: <a href="https://doi.org/10.1088/0960-1317/20/11/115036" target="_blank" rel="noopener">10.1088/0960-1317/20/11/115036</a>
            </div>
        </div>

        <!-- Entry 22 -->
        <div class="research-entry">
            <h2>Shield-layers for reducing thermoelastic damping in resonating Silicon bars</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Shield layers.png" alt="Shield-layers for reducing thermoelastic damping in resonating Silicon bars">
            </div>
            <p class="abstract">It is theoretically shown that thermoelastic incompatibility between Silicon structures and their native-oxide layers, induces thermoelastic damping. This damping dominates in structures that are packaged in vacuum and vibrate in pure axial motion. Analytic solutions of the thermoelastic response of axially loaded laminated bars are used to determine the material parameters which affect thermoelastic damping. The analysis suggests that thin shield-layers can significantly reduce thermoelastic damping which is associated with native-oxide layers in Silicon resonators.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                R. Mahameed and D. Elata, "Shield-layers for reducing thermoelastic damping in resonating Silicon bars",
                <em>J. Microsystem Technologies</em>, 15(2), 323–331, 2008.
                DOI: <a href="https://doi.org/10.1007/s00542-008-0667-3" target="_blank" rel="noopener">10.1007/s00542-008-0667-3</a>
            </div>
        </div>

        <!-- Entry 23 -->
        <div class="research-entry">
            <h2>Measuring residual stress in conductive layers</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/EMB_residual_stress.png" alt="Measuring residual stress in conductive layers">
            </div>
            <p class="abstract">A novel method for measuring residual stress is proposed and analyzed in this study. The method is based on the electromechanical bifurcation response of a clamped-clamped beam. The stressed beam is subjected to a symmetric electrostatic field. The presented analysis shows that the critical voltage which induces the bifurcation response is a monotonic function of the residual stress. Furthermore, the electromechanical bifurcation occurs for both compressive and tensile residual stresses. It is shown that a single test structure can be used to measure residual stress in a continuous wide range.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                S. Abu-Salih and D. Elata, "Experimental validation of electromechanical buckling",
                <em>IEEE-JMEMS</em>, 15(6), 1656–1662, 2006.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2006.886015" target="_blank" rel="noopener">10.1109/JMEMS.2006.886015</a>
            </div>
        </div>

        <!-- Entry 24 -->
        <div class="research-entry">
            <h2>Electromechanical buckling</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/EMB.png" alt="Electromechanical buckling">
            </div>
            <p class="abstract">The electromechanical buckling of a prestressed microbeam bonded to a dielectric elastic foundation is analyzed. It is shown that electrostatic forces can precipitately instigate buckling even when the prestress in the microbeam is lower than the critical value that would cause mechanical buckling. We show that electrostatic potential can be used to achieve on/off switching of surface flexures. An analytic solution of the critical electromechanical state is derived.</p>
            <div class="citation">
                To learn more, please refer to our papers:<br>
                S. Abu-Salih and D. Elata, "Analytic postbuckling solution of a pre-stressed infinite beam bonded to a linear elastic foundation",
                <em>Int. J. of Solids and Structures</em>, 42(23), 6048–6058, 2005.
                DOI: <a href="https://doi.org/10.1016/j.ijsolstr.2005.03.006" target="_blank" rel="noopener">10.1016/j.ijsolstr.2005.03.006</a><br><br>
                D. Elata and S. Abu-Salih, "Analysis of electromechanical buckling of a prestressed microbeam that is bonded to an elastic foundation",
                <em>Journal of Mechanics of Materials and Structures</em>, 1(5), 911–923, 2006.
                DOI: <a href="https://doi.org/10.2140/jomms.2006.1.911" target="_blank" rel="noopener">10.2140/jomms.2006.1.911</a>
            </div>
        </div>

        <!-- Entry 25 -->
        <div class="research-entry">
            <h2>Measuring the strength of brittle microbeams</h2>
            <div class="research-media">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/Images/Breaking_beams.png" alt="Measuring the strength of brittle microbeams">
            </div>
            <p class="abstract">We have developed a device and method for measuring the strength of brittle microbeams which requires no measurements of forces or displacements. Euler Bernoulli beam theory trivially predicts that the maximal tension stress in an initially straight beam is linearly proportional to the curvature of the beam when it is bent. In our device we design a curved wall over which we wrap a test beam by application of an unmeasured force. The curvature of the curved wall increases linearly with circumferential distance along the wall. Therefore, the maximal curvature in the wrapped beam occurs at the last point of contact between the beam and the curved wall.</p>
            <div class="citation">
                To learn more, please refer to our paper:
                D. Elata and A. Hirshberg, "A novel method for measuring the strength of microbeams",
                <em>IEEE-JMEMS</em>, 15(2), 396–405, 2006.
                DOI: <a href="https://doi.org/10.1109/JMEMS.2006.872237" target="_blank" rel="noopener">10.1109/JMEMS.2006.872237</a>
            </div>
        </div>

    </main>

<?php get_footer(); ?>
